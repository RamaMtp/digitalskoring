*---------------------------------------------------------------
* DIGITAL SCORING PENCAK SILAT Versi 20.01
* https://eregistrasi-kejuaraan-silat.sourceforge.io/
*---------------------------------------------------------------

Daftar Perbaikan Aplikasi Digital Scoring Pencak Silat Versi 20.01 :

+ Script mengaktifkan partai pada modul "Nilai Publik".
+ Nilai Publik: Pemisahan partai yang telah selesai dipertandingkan.
+ Nilai Publik: Informasi total partai.
+ Nilai Publik: Announcer (Text to speech); membutuhkan akses internet.
+ Login Wasit juri: Hanya menampilkan partai yang telah diaktifkan.
+ Modul Pesilat terbaik.
+ Struktur Database.
	
Pada versi ini database terletak pada folder db.


* @Creator Yudha Yogasara - yudha.yogasara@gmail.com
* @Contributor Sofyan Hadi, Satria Salam
*
* IPSI KABUPATEN TANGERANG
* 
* ...::: Made with love and caffeine :::...
*
* Tangerang, Januari 2020

***************************************************

Aplikasi Registrasi Online Kejuaraan Pencak Silat bersifat open source dan gratis. Anda dapat dengan bebas menggunakannya tanpa biaya sepeserpun. Bagi Anda yang ingin berkontribusi secara finansial berapapun nilainya dapat melakukan transfer ke nomor rekening di bawah ini:

Bank Syariah Mandiri
No. Rekening 70 888 05 148 
Atas Nama Yudha Yogasara